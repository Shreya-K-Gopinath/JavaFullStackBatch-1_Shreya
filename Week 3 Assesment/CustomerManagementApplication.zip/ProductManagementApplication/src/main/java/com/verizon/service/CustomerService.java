package com.verizon.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.verizon.dao.CustomerDao;
import com.verizon.model.Customer;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class CustomerService {
	@Autowired
	CustomerDao customerDao;

	public Customer addCustomer(Customer customer) {
		
		return customerDao.save(customer);
	}

	public List<Customer> getAllCustomers() {
		//
		return customerDao.findAll();
	}

	public Customer updateCustomer(Integer cid, String cname, String email, Customer customer) {
		
		if (customerDao.existsById(cid)) {
            customer.setCid(cid);
            customer.setCname(cname);
            customer.setEmail(email);
            return customerDao.save(customer);
        }
        return null;
	}

	public void deleteCustomer(Integer cid) {
		//
		if (customerDao.existsById(cid)) {
            customerDao.deleteById(cid);
		}    
	}
}
