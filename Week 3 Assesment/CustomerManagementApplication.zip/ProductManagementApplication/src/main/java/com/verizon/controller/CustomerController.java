package com.verizon.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.verizon.model.Customer;
import com.verizon.service.CustomerService;
@RestController
public class CustomerController {
	
	@Autowired
	CustomerService customerService;
	
	
	@GetMapping("/Customer")
	public ResponseEntity<List<Customer>> getCustomerDetails() {  // need to implement
		
		List<Customer> customers = customerService.getAllCustomers();
        return new ResponseEntity<>(customers, HttpStatus.OK);
	}

	
	  @PostMapping("/Customer") 
	  public ResponseEntity<String> addCustomerDetails(@RequestBody Customer customer) {
	        customerService.addCustomer(customer);
	        return new ResponseEntity<>("Customer added successfully", HttpStatus.CREATED);
	    }

	
	@PutMapping("/Customer/{cid}") 
	public ResponseEntity<Customer> updateCustomerDetails(@PathVariable("cid") Integer cid, @RequestBody Customer customer) {
        Customer updatedCustomer = customerService.updateCustomer(cid, customer.getCname(), customer.getEmail(), customer);
        if (updatedCustomer != null) {
            return new ResponseEntity<>(updatedCustomer, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

	
	@DeleteMapping("/Customer/{cid}") 
	public ResponseEntity<String> deleteCustomerDetails(@PathVariable("cid") Integer cid) {
		customerService.deleteCustomer(cid);
        return new ResponseEntity<>("Customer deleted successfully", HttpStatus.OK);
		 
	}
	
}
