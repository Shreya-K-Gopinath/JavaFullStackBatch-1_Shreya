package com.verizon.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.verizon.exception.ProductNotFoundException;
import com.verizon.model.Product;
import com.verizon.service.ProductService;
@RestController
public class ProductController {
	
	@Autowired
	ProductService productService;
	@GetMapping("/product")
	public List<Product> getAllProducts() {  // need to implement
		return productService.getProducts();
	}
	
	@GetMapping("/product/{id}")
	public ResponseEntity<?> getProduct(@PathVariable Integer id) {
        try {
            return ResponseEntity.ok(productService.getProduct(id));
        } catch (ProductNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
	
	@GetMapping("/product/{low}/{high}")
	public List<Product> getProductsBetweenPriceRange(@PathVariable Integer low, @PathVariable Integer high) {
        return productService.getProductsBetweenLowHigh(low, high);
    }

    @PostMapping("/product")
    public ResponseEntity<String> addProductDetails(@RequestBody Product product) {
        String result = productService.addProduct(product);
        return ResponseEntity.status(HttpStatus.CREATED).body(result);
    }

	
	@PutMapping("/product/{pid}") 
	public ResponseEntity<?> updateProductDetails(@PathVariable("pid") Integer pid, @RequestBody Product product) {
        try {
            return ResponseEntity.ok(productService.updateProduct(pid, product));
        } catch (ProductNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @DeleteMapping("/product/{pid}")
    public ResponseEntity<?> deleteProductDetails(@PathVariable("pid") Integer pid) {
        try {
            return ResponseEntity.ok(productService.deleteProduct(pid));
        } catch (ProductNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
	
}
